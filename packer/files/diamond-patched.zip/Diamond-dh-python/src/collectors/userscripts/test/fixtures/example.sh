#!/bin/sh

echo "example.1 42"
echo "example.2 24"
echo "example.3 12.1212"
# Testing invalid data is never a bad idea ;-)
echo "example.4 4 4"
echo "example.5 foo"
echo "example.6"
echo ""
