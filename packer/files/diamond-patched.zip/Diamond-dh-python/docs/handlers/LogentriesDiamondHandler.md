<!--This file was generated from the python source
Please edit the source to make changes
-->
LogentriesDiamondHandler
====

[Logentries: Log Management & Analytics Made Easy ](https://logentries.com/).
Send Diamond stats to your Logentries Account where you can monitor and alert
based on data in real time.
#### Options

Setting | Default | Description | Type
--------|---------|-------------|-----
get_default_config_help |  | get_default_config_help | 
log_token |  | [Your log token](https://logentries.com/doc/input-token/) | str
queue_size | 100 |  | int
server_error_interval | 120 | How frequently to send repeated server errors | int
