<!--This file was generated from the python source
Please edit the source to make changes
-->
rmqHandler
====

Output the collected values to RabitMQ pub/sub channel
#### Options

Setting | Default | Description | Type
--------|---------|-------------|-----
get_default_config_help |  | get_default_config_help | 
rmq_exchange | diamond |  | str
server | 127.0.0.1 |  | str
server_error_interval | 120 | How frequently to send repeated server errors | int
