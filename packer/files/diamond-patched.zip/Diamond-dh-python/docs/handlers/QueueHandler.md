<!--This file was generated from the python source
Please edit the source to make changes
-->
QueueHandler
====

This is a meta handler to act as a shim for the new threading model. Please
do not try to use it as a normal handler
#### Options

Setting | Default | Description | Type
--------|---------|-------------|-----
get_default_config_help |  | get_default_config_help | 
server_error_interval | 120 | How frequently to send repeated server errors | int
