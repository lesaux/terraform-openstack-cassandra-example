# Related Projects

## Integrations

 * [puppet-diamond](https://github.com/vimeo/puppet-diamond) - diamond module for puppet
 * [chef-diamond](https://github.com/CBarraford/diamond_cookbook) - diamond cookbook for chef (Reported Broken)
 * [chef-diamond](https://github.com/damm/diamond) - Alternative diamond cookbook for chef (Reported Broken)
 * [graph-explorer](https://github.com/Dieterbe/graph-explorer) - graphite dashboard that comes with templates for diamond plugins
 * [graph-index](https://github.com/huoxy/graph-index) - index of graphs for diamond
